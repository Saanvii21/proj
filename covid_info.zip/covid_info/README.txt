STQA MINI PROJECT: COVID-19 INFORMATION WEBSITE
Technology: HTML, CSS, JavaScript, PHP, MySQL, Python 3 Regex tests

IMPORTANT SETUP FOR THIS COMPUTER
- XAMPP Apache is used to run PHP.
- Your existing MySQL80 server is used for the database.
- Do NOT start XAMPP MySQL because MySQL80 already uses the MySQL service/port.
- Copy this folder to C:\xampp\htdocs\covid_info

1. DATABASE SETUP
   a. Open MySQL Workbench and connect to Local instance MySQL80.
   b. Open the file database.sql in Workbench (File > Open SQL Script).
   c. Execute the complete script using the lightning bolt.
   d. The script creates database covid_info and tables:
      registrations, users, comments, covid_content.

2. PHP DATABASE CONNECTION
   Open config.php.
   The default settings are:
      host = 127.0.0.1
      port = 3306
      user = root
      password = (blank)
   If your MySQL root account has a password, enter it in config.php.
   Do not share your password or upload config.php publicly.

3. RUN THE WEBSITE
   a. Start Apache in XAMPP.
   b. Open: http://localhost/covid_info/
   c. Register a new account, then log in and add a comment.

4. RUN REGEX TESTS
   Install Python 3 if needed.
   Open Command Prompt in the project folder and run:
      python tests/regex_tests.py
   It contains 29 valid/invalid test cases for the seven fields in the report.

PROJECT FEATURES
- Home page: COVID-19 overview, symptoms and prevention loaded from MySQL.
- Registration: JavaScript validation + PHP validation + MySQL storage.
- Login: username/password authentication using password_hash/password_verify.
- Comments: logged-in users can submit comments; server-side validation is applied.
- Logout: destroys the session.
- Regex testing: 29 Python test cases with PASS/FAIL totals.

REGEX NOTE
The date regex in the supplied mini-project report checks YYYY-MM-DD format and
month/day ranges, but it does not check month-specific calendar validity (for
example, it can match 2026-02-31). This project preserves the report's regex.

DEMO CHECKLIST
1. Show homepage and database-driven symptoms/prevention.
2. Register with invalid values: JavaScript should reject them.
3. Register with valid values: record should appear in registrations and users.
4. Log in with the new account.
5. Submit a normal comment.
6. Try a comment containing <script> and show that it is rejected.
7. Run the Python regex test file and show 29 passed, 0 failed.
