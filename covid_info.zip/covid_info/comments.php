<?php
require_once 'config.php';
require_once 'functions.php';
require_login();
$pageTitle = 'Community comments';
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment = trim($_POST['comment'] ?? '');
    if (!valid_field('comment', $comment)) {
        $error = 'Comment must contain 1–200 characters and cannot contain < or >.';
    } else {
        $stmt = $conn->prepare('INSERT INTO comments (user_id, comment_text) VALUES (?, ?)');
        $stmt->bind_param('is', $_SESSION['user_id'], $comment);
        $stmt->execute();
        $success = 'Your comment has been posted.';
    }
}
$comments = $conn->query('SELECT comments.comment_text, comments.created_at, users.username FROM comments JOIN users ON comments.user_id = users.user_id ORDER BY comments.created_at DESC');
require 'header.php';
?>
<section class="section-heading comments-heading"><p class="eyebrow">COMMUNITY SPACE</p><h1>Comments</h1><p>Share a relevant question or suggestion. Comments are validated on the server before saving.</p></section>
<div class="comments-layout">
    <form class="form-card comment-form" method="post">
        <h2>Write a comment</h2>
        <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>
        <div class="field"><label for="comment">Your comment</label><textarea id="comment" name="comment" rows="5" maxlength="200" required data-rule="comment" placeholder="Write something helpful..."></textarea><small>Maximum 200 characters. Angle brackets are not allowed.</small></div>
        <button class="button full" type="submit">Post comment</button>
    </form>
    <div class="comment-list"><h2>Recent comments</h2>
        <?php if ($comments->num_rows === 0): ?><p class="muted">No comments yet. Be the first to post.</p><?php endif; ?>
        <?php while ($row = $comments->fetch_assoc()): ?>
            <article class="comment"><div class="comment-meta"><strong><?= e($row['username']) ?></strong><time><?= e($row['created_at']) ?></time></div><p><?= e($row['comment_text']) ?></p></article>
        <?php endwhile; ?>
    </div>
</div>
<?php require 'footer.php'; ?>
