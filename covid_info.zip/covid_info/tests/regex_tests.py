import re

# These patterns follow the STQA mini-project report.
patterns = {
    "name": r"^[A-Za-z][A-Za-z ]{2,29}$",
    "email": r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$",
    "mobile": r"^[6-9][0-9]{9}$",
    "password": r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$",
    "username": r"^[A-Za-z][A-Za-z0-9_]{3,15}$",
    "date": r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$",
    "comment": r"^[^<>]{1,200}$",
}

# (field, input, expected_validity) = 29 test cases
test_cases = [
    ("name", "Saanvi Mankar", True),
    ("name", "Amit", True),
    ("name", "Jo", False),
    ("name", "John123", False),

    ("email", "student@example.com", True),
    ("email", "a.b+test@mail.co.in", True),
    ("email", "studentexample.com", False),
    ("email", "student@domain", False),

    ("mobile", "9876543210", True),
    ("mobile", "6123456789", True),
    ("mobile", "5123456789", False),
    ("mobile", "987654321", False),

    ("password", "Hello@123", True),
    ("password", "Strong#Pass9", True),
    ("password", "hello@123", False),
    ("password", "Hello123", False),

    ("username", "Saanvi_21", True),
    ("username", "User1", True),
    ("username", "1user", False),
    ("username", "ab", False),

    ("date", "2026-11-15", True),
    ("date", "2004-02-29", True),
    ("date", "2026-13-01", False),
    ("date", "15-11-2026", False),

    ("comment", "Stay safe everyone.", True),
    ("comment", "Please share official updates.", True),
    ("comment", "OK", True),
    ("comment", "<script>alert(1)</script>", False),
    ("comment", "A" * 201, False),
]

def test_regex(field, value, expected):
    actual = re.fullmatch(patterns[field], value) is not None
    status = "PASS" if actual == expected else "FAIL"
    print(f"{status:4} | {field:8} | {value!r:35} | expected={expected}, actual={actual}")
    return status == "PASS"

def main():
    passed = 0
    failed = 0
    print("COVID-19 WEBSITE - REGULAR EXPRESSION TESTING")
    print("-" * 105)
    for field, value, expected in test_cases:
        if test_regex(field, value, expected):
            passed += 1
        else:
            failed += 1
    print("-" * 105)
    print(f"Total test cases: {len(test_cases)}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print("Overall result:", "ALL TESTS PASSED" if failed == 0 else "SOME TESTS FAILED")

if __name__ == "__main__":
    main()
