<?php require_once __DIR__ . '/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) : 'COVID-19 Information' ?></title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/validation.js" defer></script>
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="index.php">COVID<span>Info</span></a>
        <nav>
            <a href="index.php">Home</a>
            <?php if (is_logged_in()): ?>
                <a href="comments.php">Comments</a>
                <span class="nav-user">Hi, <?= e($_SESSION['username']) ?></span>
                <a class="nav-button" href="logout.php">Logout</a>
            <?php else: ?>
                <a href="register.php">Register</a>
                <a class="nav-button" href="login.php">Login</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="container">
