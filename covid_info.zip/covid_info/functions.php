<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function regex_patterns() {
    return [
        'name' => '/^[A-Za-z][A-Za-z ]{2,29}$/',
        'email' => '/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/',
        'mobile' => '/^[6-9][0-9]{9}$/',
        'password' => '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/',
        'username' => '/^[A-Za-z][A-Za-z0-9_]{3,15}$/',
        'date' => '/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/',
        'comment' => '/^[^<>]{1,200}$/'
    ];
}

function valid_field($field, $value) {
    $patterns = regex_patterns();
    return isset($patterns[$field]) && preg_match($patterns[$field], $value) === 1;
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}
?>
