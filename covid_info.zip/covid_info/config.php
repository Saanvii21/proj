<?php
// Update DB_PASS if your MySQL root account has a password.
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);
define('DB_NAME', 'covid_info');
define('DB_USER', 'root');
define('DB_PASS', 'Root');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
    $conn->set_charset('utf8mb4');
}catch (mysqli_sql_exception $e) {
    die("MySQL Error: " . $e->getMessage());
}
?>
