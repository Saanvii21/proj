<?php
require_once 'config.php';
require_once 'functions.php';
$pageTitle = 'Login';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!valid_field('username', $username) || $password === '') {
        $error = 'Enter a valid username and password.';
    } else {
        $stmt = $conn->prepare('SELECT user_id, username, password_hash FROM users WHERE username = ?');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if ($user && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            header('Location: comments.php');
            exit;
        }
        $error = 'Incorrect username or password.';
    }
}
require 'header.php';
?>
<section class="form-shell single">
    <div class="form-intro"><p class="eyebrow">WELCOME BACK</p><h1>Log in</h1><p>Sign in to share comments and participate in the community section.</p></div>
    <form class="form-card" method="post">
        <h2>Account login</h2>
        <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
        <div class="field"><label for="username">Username</label><input id="username" name="username" required data-rule="username"></div>
        <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" required></div>
        <button class="button full" type="submit">Log in</button>
        <p class="form-bottom">New here? <a href="register.php">Create an account</a></p>
    </form>
</section>
<?php require 'footer.php'; ?>
