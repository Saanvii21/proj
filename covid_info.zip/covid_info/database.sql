CREATE DATABASE IF NOT EXISTS covid_info
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE covid_info;

CREATE TABLE IF NOT EXISTS registrations (
    registration_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(30) NOT NULL,
    email VARCHAR(254) NOT NULL,
    mobile VARCHAR(10) NOT NULL,
    birth_date DATE NOT NULL,
    username VARCHAR(16) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(16) NOT NULL UNIQUE,
    email VARCHAR(254) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS comments (
    comment_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    comment_text VARCHAR(200) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_comments_user FOREIGN KEY (user_id)
      REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS covid_content (
    content_id INT AUTO_INCREMENT PRIMARY KEY,
    section_key VARCHAR(40) NOT NULL UNIQUE,
    heading VARCHAR(100) NOT NULL,
    body TEXT NOT NULL
);

INSERT INTO covid_content (section_key, heading, body) VALUES
('overview', 'About COVID-19',
 'COVID-19 is an infectious disease caused by the SARS-CoV-2 virus. It can spread from an infected person through respiratory particles. Follow current advice from local public-health authorities.'),
('symptoms', 'Common symptoms',
 'Fever, cough, tiredness, sore throat, headache, body aches and loss of taste or smell may occur. Symptoms can vary from person to person. Seek medical advice for concerning symptoms.'),
('prevention', 'Prevention',
 'Stay up to date with recommended vaccinations, improve indoor ventilation, practise good hand hygiene, and consider a well-fitting mask in crowded or high-risk settings. Stay home when unwell and follow local health guidance.')
ON DUPLICATE KEY UPDATE heading=VALUES(heading), body=VALUES(body);
