const patterns = {
  name: /^[A-Za-z][A-Za-z ]{2,29}$/,
  email: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/,
  mobile: /^[6-9][0-9]{9}$/,
  password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/,
  username: /^[A-Za-z][A-Za-z0-9_]{3,15}$/,
  date: /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/,
  comment: /^[^<>]{1,200}$/
};

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('registerForm');
  if (form) {
    form.addEventListener('submit', (event) => {
      const message = document.getElementById('formMessage');
      const fields = [...form.querySelectorAll('[data-rule]')];
      const invalid = fields.filter((field) => {
        const rule = field.dataset.rule;
        return !patterns[rule].test(field.value.trim());
      });
      if (invalid.length) {
        event.preventDefault();
        invalid.forEach((field) => field.classList.add('invalid'));
        message.textContent = 'Please correct the highlighted fields before submitting.';
        message.className = 'form-message error-text';
        invalid[0].focus();
      }
    });
  }

  document.querySelectorAll('[data-rule]').forEach((field) => {
    field.addEventListener('input', () => {
      const rule = field.dataset.rule;
      field.classList.toggle('invalid', field.value !== '' && !patterns[rule].test(field.value.trim()));
    });
  });
});
