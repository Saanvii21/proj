</main>
<footer class="site-footer">
    <div class="container">
        <p>COVID-19 Information Portal · STQA Mini Project · Educational demonstration</p>
        <p class="small">For health concerns, consult a qualified healthcare professional and follow current public-health guidance.</p>
    </div>
</footer>
</body>
</html>
