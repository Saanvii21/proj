<?php
require_once 'config.php';
require_once 'functions.php';
$pageTitle = 'Create account';
$errors = [];
$success = '';
$values = ['name'=>'','email'=>'','mobile'=>'','date'=>'','username'=>''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($values as $key => $_) $values[$key] = trim($_POST[$key] ?? '');
    $password = $_POST['password'] ?? '';
    foreach ($values as $field => $value) {
        if (!valid_field($field, $value)) $errors[] = 'Please enter a valid ' . $field . '.';
    }
    if (!valid_field('password', $password)) $errors[] = 'Password must be at least 8 characters and include lowercase, uppercase, number and one allowed symbol.';
    if (!$errors) {
        try {
            $conn->begin_transaction();
            $stmt = $conn->prepare('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)');
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt->bind_param('sss', $values['username'], $values['email'], $hash);
            $stmt->execute();
            $stmt = $conn->prepare('INSERT INTO registrations (full_name, email, mobile, birth_date, username) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('sssss', $values['name'], $values['email'], $values['mobile'], $values['date'], $values['username']);
            $stmt->execute();
            $conn->commit();
            $success = 'Account created successfully. You can now log in.';
            $values = array_fill_keys(array_keys($values), '');
        } catch (mysqli_sql_exception $ex) {
            $conn->rollback();
            $errors[] = 'That username or email may already be registered. Please try another.';
        }
    }
}
require 'header.php';
?>
<section class="form-shell">
    <div class="form-intro"><p class="eyebrow">JOIN THE PORTAL</p><h1>Create your account</h1><p>Enter your details below. The form is checked in JavaScript and again in PHP before data is stored.</p><div class="mini-note">Your password is stored as a secure hash, not as plain text.</div></div>
    <form class="form-card" method="post" id="registerForm" novalidate>
        <h2>Registration</h2>
        <?php if ($success): ?><div class="alert success"><?= e($success) ?> <a href="login.php">Log in</a></div><?php endif; ?>
        <?php if ($errors): ?><div class="alert error"><ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <div class="field"><label for="name">Full name</label><input id="name" name="name" value="<?= e($values['name']) ?>" required data-rule="name" placeholder="e.g. Saanvi Mankar"><small>3–30 letters and spaces.</small></div>
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" value="<?= e($values['email']) ?>" required data-rule="email" placeholder="name@example.com"></div>
        <div class="field"><label for="mobile">Mobile number</label><input id="mobile" name="mobile" value="<?= e($values['mobile']) ?>" required data-rule="mobile" placeholder="10-digit Indian mobile number"></div>
        <div class="field"><label for="date">Date</label><input id="date" name="date" type="date" value="<?= e($values['date']) ?>" required data-rule="date"></div>
        <div class="field"><label for="username">Username</label><input id="username" name="username" value="<?= e($values['username']) ?>" required data-rule="username" placeholder="4–16 characters"></div>
        <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" required data-rule="password" placeholder="Create a strong password"><small>At least 8 characters: upper, lower, number and symbol.</small></div>
        <p id="formMessage" class="form-message" aria-live="polite"></p>
        <button class="button full" type="submit">Create account</button>
        <p class="form-bottom">Already registered? <a href="login.php">Log in</a></p>
    </form>
</section>
<?php require 'footer.php'; ?>
