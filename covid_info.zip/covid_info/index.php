<?php
require_once 'config.php';
$pageTitle = 'COVID-19 Information';
$result = $conn->query("SELECT section_key, heading, body FROM covid_content ORDER BY content_id");
$sections = [];
while ($row = $result->fetch_assoc()) $sections[$row['section_key']] = $row;
require 'header.php';
?>
<section class="hero">
    <div class="hero-copy">
        <p class="eyebrow">HEALTH INFORMATION</p>
        <h1>Stay informed.<br><span>Stay protected.</span></h1>
        <p>Simple, useful information about COVID-19, its symptoms and ways to reduce the risk of infection.</p>
        <div class="hero-actions">
            <a class="button" href="register.php">Create an account</a>
            <a class="button button-light" href="#learn">Explore information</a>
        </div>
    </div>
    <div class="hero-art" aria-hidden="true"><div class="virus">✳</div><div class="art-label">Knowledge helps protect communities</div></div>
</section>
<section id="learn" class="section-heading">
    <p class="eyebrow">KNOW THE BASICS</p><h2>COVID-19 information</h2>
    <p>These information cards are retrieved dynamically from the MySQL database.</p>
</section>
<div class="info-grid">
<?php foreach ($sections as $section): ?>
    <article class="info-card">
        <div class="card-mark"><?= $section['section_key'] === 'symptoms' ? '＋' : ($section['section_key'] === 'prevention' ? '✓' : 'i') ?></div>
        <h3><?= e($section['heading']) ?></h3>
        <p><?= e($section['body']) ?></p>
    </article>
<?php endforeach; ?>
</div>
<section class="callout">
    <div><p class="eyebrow">COMMUNITY</p><h2>Have a question or suggestion?</h2><p>Register, sign in and share a comment with the community.</p></div>
    <a class="button" href="<?= is_logged_in() ? 'comments.php' : 'register.php' ?>">Join the conversation</a>
</section>
<?php require 'footer.php'; ?>
